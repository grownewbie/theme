module.exports = {
  Inventory: {
    qty: (inventory) => inventory.qty || 0
  }
};
